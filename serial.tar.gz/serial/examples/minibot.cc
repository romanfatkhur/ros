
#include <stdlib.h>
#include <string>
#include <iostream>
#include <cstdio>
#include <unistd.h>
#include <string>
#include <sstream>
#include "serial/serial.h"

#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float32.h"
#include "geometry_msgs/Vector3.h"
#include "sensor_msgs/Imu.h"
#include <nav_msgs/Odometry.h>

using std::string;
using std::exception;
using std::cout;
using std::cerr;
using std::endl;
using std::vector;
using namespace std;

float x, y;
const double degree = M_PI/180;
long angle;
void subscribe_android_imu(const sensor_msgs::Imu::ConstPtr &imu){
  x = imu->linear_acceleration.x * 3.14;
  y = imu->linear_acceleration.y * 10 ;
  cout << "[x["<< x <<"], y["<< y << "]\n";
}
void subscribe_cmd_vel(const geometry_msgs::Twist::ConstPtr &speed) {
  x = speed->linear.x*40;
  y = speed->linear.z*40;
}
void my_sleep(unsigned long milliseconds) {
  usleep(milliseconds*1000); // 100 ms
}
void enumerate_ports() {
  vector<serial::PortInfo> devices_found = serial::list_ports();
  vector<serial::PortInfo>::iterator iter = devices_found.begin();
  while( iter != devices_found.end() ) {
    serial::PortInfo device = *iter++;
    printf( "(%s, %s, %s)\n", device.port.c_str(), device.description.c_str(),
            device.hardware_id.c_str() );
  }
}
void print_usage() {
  cerr << "Usage: test_serial {-e|<serial port address>} ";
  cerr << "<baudrate> [test string]" << endl;
}
int run(int argc, char **argv) {
  if(argc < 2) {
    print_usage();
    return 0;
  }
  
  // Argument 1 is the serial port or enumerate flag
  string port(argv[1]);
  
  if( port == "-e" ) {
    enumerate_ports();
    return 0;
  }
  else if( argc < 3 ) {
    print_usage();
    return 1;
  }
  
  unsigned long baud = 0;
  sscanf(argv[2], "%lu", &baud);
  serial::Serial my_serial(port, baud, serial::Timeout::simpleTimeout(1000));
  ros::init(argc, argv, "minibot_control");
  ros::NodeHandle n;
  ros::Subscriber sub_android_imu = n.subscribe<sensor_msgs::Imu>("/android/imu", 1, subscribe_android_imu);
  ros::Subscriber sub_rqt=n.subscribe<geometry_msgs::Twist>("/cmd_vel", 1, subscribe_cmd_vel);
  ros::Rate loop_rate(50);
  ros::Publisher odom_pub = n.advertise<nav_msgs::Odometry>("odom", 50); 
  
  string cmd_left, cmd_right;
  double trans, rot;
  double trans_old;
  string cmd;

  while (ros::ok()) {
    ros::Time current_time = ros::Time::now(); 
    cmd = "odo\n\r";
    my_serial.write(cmd);
    my_sleep(100);
    string tmp;
    my_serial.readline(tmp, 20, "#");
    tmp.clear();
    my_serial.readline(tmp, 20, ">&");
    // cout << tmp<<endl;
    int start_pos = tmp.find_first_of('<');
    int delim = tmp.find_first_of(':');
    int stop = tmp.find_first_of('>');
    // cout << start_pos <<","<<delim<<","<<stop<<endl;;
    nav_msgs::Odometry odom;
    // ==================== odom reading and send it to rviz ========================
    if (start_pos != -1){
      string left_odo_str =tmp.substr(start_pos+1,delim-1);
      string right_odo_str =tmp.substr(start_pos+delim+1,stop-1);
      // cout<<"l:"<<left_odo_str<<"r:"<<right_odo_str<<endl;
      int l_odo = stoi(left_odo_str);
      int r_odo = stoi(right_odo_str);
      // cout<<"l_odo["<<l_odo<<"], r_odo["<<r_odo<<"]"<<endl;
    }
    // ==================== end of odom reading and send it to rviz ========================
    // ================= wheel control =========================
    tmp.clear();
    trans = x;
    rot = y;
    if ((trans_old != trans)){
      if (trans > 0){
        cmd_left = "lmf " + std::to_string(trans)+"\n\r";
        cmd_right = "rmf " + std::to_string(trans)+"\n\r";
      }else if (trans < 0){
        trans= abs(trans);
        cmd_left = "lmb " + std::to_string(trans)+"\n\r";
        cmd_right = "rmb " + std::to_string(trans)+"\n\r";
      }
      my_serial.write(cmd_left);
      my_sleep(100);
      my_serial.write(cmd_right);
      my_sleep(100);
    }
    if (trans_old != trans){
      trans_old = trans;
    }
    // angle += degree/4;
    // ================= end of wheel control =========================
    odom_pub.publish(odom);
    ros::spinOnce();    
    loop_rate.sleep();
  }
  return 0;
}
int main(int argc, char **argv) {
  try {
    return run(argc, argv);
  } catch (exception &e) {
    cerr << "Unhandled Exception: " << e.what() << endl;
  }
}
