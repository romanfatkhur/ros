
#include <stdlib.h>
#include <string>
#include <iostream>
#include <cstdio>
#include <unistd.h>
#include <string>
#include <sstream>
#include "serial/serial.h"

#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float32.h"
#include "geometry_msgs/Vector3.h"
#include "sensor_msgs/Imu.h"
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/Joy.h>
using std::string;
using std::exception;
using std::cout;
using std::cerr;
using std::endl;
using std::vector;
using namespace std;

float x, y, z;
const double degree = M_PI/180;
long angle;
bool buzzer = false;

int rot = 0;
double Vr_old = 0, Vr_new=0, R = 6;
double Vl_old = 0, Vl_new=0, L = 10;
void subscribe_android_imu(const sensor_msgs::Imu::ConstPtr &imu){
  x = imu->linear_acceleration.x * 3.14;
  y = imu->linear_acceleration.y * 10 ;
  cout << "[x["<< x <<"], y["<< y << "]\n";
}
void subscribe_cmd_vel(const geometry_msgs::Twist::ConstPtr &speed) {
  x = speed->linear.x*10;
  z = speed->linear.z*10;
}
void subscribe_joy(const sensor_msgs::Joy::ConstPtr& joy) {
  if(joy->buttons[4] == 1){
    Vl_new = 1;
    Vr_new = 99;
  }else if(joy->buttons[5]){
    Vl_new = 99;
    Vr_new = 1;
  }
  if(joy->axes[0] == 1){
    Vr_new += joy->axes[0]*0.5*(R-(L/2));
    Vl_new += joy->axes[0]*0.5*(R+(L/2));
  }else if(joy->axes[0] == -1){
    Vr_new -= abs(joy->axes[0])*0.5*(R-(L/2));
    Vl_new -= abs(joy->axes[0])*0.5*(R+(L/2));
  }
  if(joy->axes[1] == 1){
    Vr_new += joy->axes[1]*5;
    Vl_new += joy->axes[1]*5;
  }else if(joy->axes[1] == -1){
    Vr_new -= abs(joy->axes[1])*5;
    Vl_new -= abs(joy->axes[1])*5;
  }
  if (joy->buttons[2] == 1){
    Vl_new = 0;
    Vr_new = 0;
  }
  if(joy->buttons[0] == 1){
    buzzer = true;
  }else{
    buzzer = false;
  }
  if(joy->buttons[3] == 1){
    rot = 1;
  }else if (joy->buttons[1] == 1){
    rot =2;
  }else{
    rot =0;
  }
}
void my_sleep(unsigned long milliseconds) {
  usleep(milliseconds*1000); // 100 ms
}
void enumerate_ports() {
  vector<serial::PortInfo> devices_found = serial::list_ports();
  vector<serial::PortInfo>::iterator iter = devices_found.begin();
  while( iter != devices_found.end() ) {
    serial::PortInfo device = *iter++;
    printf( "(%s, %s, %s)\n", device.port.c_str(), device.description.c_str(),
            device.hardware_id.c_str() );
  }
}
void print_usage() {
  cerr << "Usage: test_serial {-e|<serial port address>} ";
  cerr << "<baudrate> [test string]" << endl;
}
int run(int argc, char **argv) {
  if(argc < 2) {
    print_usage();
    return 0;
  }
  
  // Argument 1 is the serial port or enumerate flag
  string port(argv[1]);
  
  if( port == "-e" ) {
    enumerate_ports();
    return 0;
  }
  else if( argc < 3 ) {
    print_usage();
    return 1;
  }
  
  unsigned long baud = 0;
  sscanf(argv[2], "%lu", &baud);
  serial::Serial my_serial(port, baud, serial::Timeout::simpleTimeout(1000));
  ros::init(argc, argv, "minibot_control");
  ros::NodeHandle n;
  ros::Subscriber sub_android_imu = n.subscribe<sensor_msgs::Imu>("/android/imu", 1, subscribe_android_imu);
  ros::Subscriber sub_rqt=n.subscribe<geometry_msgs::Twist>("/cmd_vel", 1, subscribe_cmd_vel);
  ros::Subscriber sub_joy=n.subscribe<sensor_msgs::Joy>("/joy", 1, subscribe_joy);
  ros::Rate loop_rate(5);
  
  string cmd_left, cmd_right;
  string cmd;

  while (ros::ok()) {
    // ================= wheel control =========================
    if(Vl_old != Vl_new){
      cout << "L=["<< Vl_new <<"]";
      cout << "R=["<< Vr_new <<"]\n";
      if ((Vl_new > 0) && (Vr_new > 0)){
        cmd_left = "lmf " + std::to_string(Vl_new)+"\n\r";
        cmd_right = "rmf " + std::to_string(Vr_new)+"\n\r";
        cout << "maju" << "\n";
      }else if ((Vl_new < 0) && (Vr_new < 0)){
        // Vl_new= abs(Vl_new);
        // Vr_new= abs(Vr_new);
        cmd_left = "lmb " + std::to_string(abs(Vl_new))+"\n\r";
        cmd_right = "rmb " + std::to_string(abs(Vr_new))+"\n\r";
        cout << "mundur" << "\n";
      }else if ((Vl_new == 0) && (Vr_new == 0)){
        cmd_left = "lmb " + std::to_string(0)+"\n\r";
        cmd_right = "rmb " + std::to_string(0)+"\n\r";
      }
      my_serial.write(cmd_left);
      my_sleep(10);
      my_serial.write(cmd_right);
      my_sleep(10);
      Vl_old = Vl_new;
      
    }
    if(rot == 1){
      cmd_left = "lmb " + std::to_string(30)+"\n\r";
      cmd_right = "rmf " + std::to_string(30)+"\n\r";
    }else if(rot ==2){
      cmd_left = "lmf " + std::to_string(30)+"\n\r";
      cmd_right = "rmb " + std::to_string(30)+"\n\r";
    }
    if (rot > 0){
      my_serial.write(cmd_left);
      my_sleep(10);
      my_serial.write(cmd_right);
      my_sleep(10);
    }

    if(buzzer){
      // my_serial.write("buzzer_on\n\r");
    }else {
      // my_serial.write("buzzer_off\n\r");
    }
    // ================= end of wheel control =========================
    ros::spinOnce();    
    loop_rate.sleep();
  }
  return 0;
}
int main(int argc, char **argv) {
  try {
    return run(argc, argv);
  } catch (exception &e) {
    cerr << "Unhandled Exception: " << e.what() << endl;
  }
}
