
#include <stdlib.h>
#include <string>
#include <iostream>
#include <cstdio>
#include <unistd.h>
#include <string>
#include <sstream>
#include "serial/serial.h"

#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float32.h"
#include "geometry_msgs/Vector3.h"
#include "sensor_msgs/Imu.h"

using std::string;
using std::exception;
using std::cout;
using std::cerr;
using std::endl;
using std::vector;
using namespace std;

int main(int argc, char *argv[])
{

  string cmd = "LMF " + std::to_string(12)+"\n\r";
  cout <<cmd  << "\n";
  while (1) {
    
  }
  return 0;
}
